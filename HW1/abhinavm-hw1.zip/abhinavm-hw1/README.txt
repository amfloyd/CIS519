Turning in 2 hours late

Name- Abhinav Malik
E-mail id- abhinavm@seas.upenn.edu

The code runs properly but every time I tried a new classifier, I removed the previous one and replace it with the new one. I apologise for any confusions in reading the code. Also, I tried exporting the trees now but only got .(dot) files which I wasn’t able to convert into png image or something else. I’m adding those files as well where 2b stands for second question and second classifier. 